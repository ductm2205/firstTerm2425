package com.se1.tut07.controller;

import com.se1.tut07.model.Employee;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.se1.tut07.repository.EmployeeRepository;

import java.util.List;

// EmployeeController.java
@Controller
public class EmployeeController {
    //    @Autowired
    //    private EmployeeRepository employeeRepository;
    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }


    @RequestMapping(value = "/list")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public String getAllEmployee(Model model) {
        List<Employee> employeeList = employeeRepository.findAll();
        model.addAttribute("employees", employeeList);
        return "employee/employeeList";
    }

    @RequestMapping(value = "/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public String getEmployeeId(@PathVariable("id") Long id, Model model) {
        Employee employee = employeeRepository.findById(id).get();
        model.addAttribute("employee", employee);
        return "employee/employeeDetail";
    }


    // CREATE
    @GetMapping(value = "/create")
    @PreAuthorize("hasRole('ADMIN')")
    public String createNewEmployee(Model model) {
        model.addAttribute("employee", new Employee());
        return "employee/employeeAdd";
    }

    @PostMapping("/create")
    @PreAuthorize("hasRole('ADMIN')")

    public String saveNewEmployee(Model model, @Valid @ModelAttribute Employee employee, BindingResult result) {
        if (result.hasErrors()) {
            model.addAttribute("error", result.getAllErrors());
            return "employee/employeeAdd";
        }
        try {
            employeeRepository.save(employee);
            return "redirect:/list";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to save employee. Please try again.");
            return "employee/employeeAdd";
        }
    }


    // Show update employee form
    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")


    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid employee Id:" + id));
        model.addAttribute("employee", employee);
        return "employee/employeeEdit";
    }

    // Update employee
    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ADMIN')")

    public String updateEmployee(@PathVariable("id") Long id, @Valid @ModelAttribute Employee employee, BindingResult result) {

        if (result.hasErrors()) {
            if (id == null) {
                return "redirect:/create";
            } else {
                return "employee/employeeEdit";
            }
        }
        employee.setId(id);  // Ensure the ID is set correctly
        employeeRepository.save(employee);
        return "redirect:/list";
    }

    // Delete employee
    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")

    public String deleteEmployee(@PathVariable("id") Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid employee Id:" + id));
        employeeRepository.delete(employee);
        return "redirect:/";
    }

    // Handle employee not found exception
    @ExceptionHandler(IllegalArgumentException.class)
    public String handleNotFound(Model model, IllegalArgumentException exception) {
        model.addAttribute("error", exception.getMessage());
        return "error";
    }

}