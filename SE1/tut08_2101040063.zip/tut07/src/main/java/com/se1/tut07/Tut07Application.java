package com.se1.tut07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut07Application {

	public static void main(String[] args) {
		SpringApplication.run(Tut07Application.class, args);
	}

}
