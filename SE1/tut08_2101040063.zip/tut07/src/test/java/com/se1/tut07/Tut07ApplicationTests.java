package com.se1.tut07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
