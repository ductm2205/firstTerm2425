package com.se1.tut07.repository;

import com.se1.tut07.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // EmployeeRepository.java
    List<Employee> findByNameContainingIgnoreCase(String name);
}
