package com.se1.tut07.controller;

import com.se1.tut07.model.Role;
import com.se1.tut07.model.User;
import com.se1.tut07.service.UserService;
import org.hibernate.validator.internal.util.logging.Log;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }


    @GetMapping(value = "/")
    public String index() {
        return "index";
    }

    @GetMapping("/login")
    public String loginPage(Authentication authentication) {
        // If user is already logged in, redirect to home page
        if (authentication != null && authentication.isAuthenticated()) {
            return "redirect:/";
        }
        return "user/login";
    }

    @GetMapping(value = "/register")
    public String registerForm(Model model, Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            return "redirect:/";
        }
        model.addAttribute("user", new User());
        return "user/register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model, RedirectAttributes redirectAttributes) {
        try {
            userService.registerNewUser(user);
            redirectAttributes.addFlashAttribute("success", "Registration successful! Please login.");
            return "redirect:/login";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "user/register";
        }
    }
}
