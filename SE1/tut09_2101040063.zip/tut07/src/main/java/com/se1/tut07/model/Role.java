package com.se1.tut07.model;

public enum Role {
    ADMIN,
    USER,
}
