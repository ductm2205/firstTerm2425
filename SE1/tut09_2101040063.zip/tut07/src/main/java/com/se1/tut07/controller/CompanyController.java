package com.se1.tut07.controller;

import com.se1.tut07.model.Company;
import com.se1.tut07.model.Employee;
import com.se1.tut07.repository.CompanyRepository;
import com.se1.tut07.repository.EmployeeRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/companies")
public class CompanyController {

    @Autowired
    private CompanyRepository companyRepository;

    @GetMapping("/")
    public String listCompanies(Model model) {
        List<Company> companies = companyRepository.findAll();
        model.addAttribute("companies", companies);
        return "company/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("company", new Company());
        return "company/add";
    }

    @PostMapping("/save")
    public String saveCompany(@Valid @ModelAttribute("company") Company company, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "company/add";
        }
        companyRepository.save(company);
        return "redirect:/companies/";
    }

    @GetMapping("/{id}")
    public String showCompanyDetails(@PathVariable("id") Long id, Model model) {
        Optional<Company> optionalCompany = companyRepository.findById(id);
        if (optionalCompany.isPresent()) {
            model.addAttribute("company", optionalCompany.get());
            return "company/detail";
        } else {
            return "redirect:/companies/";
        }
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Company> optionalCompany = companyRepository.findById(id);
        if (optionalCompany.isPresent()) {
            model.addAttribute("company", optionalCompany.get());
            return "company/edit";
        } else {
            return "redirect:/companies/";
        }
    }

    @PostMapping("/{id}/update")
    public String updateCompany(@PathVariable("id") Long id, @Valid @ModelAttribute("company") Company company, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "company/edit";
        }
        company.setId(id);
        companyRepository.save(company);
        return "redirect:/companies/";
    }

    @GetMapping("/{id}/delete")
    public String deleteCompany(@PathVariable("id") Long id) {
        companyRepository.deleteById(id);
        return "redirect:/companies/";
    }
}
