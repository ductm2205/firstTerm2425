package com.se1.tut07.controller;

import com.se1.tut07.model.Company;
import com.se1.tut07.model.Employee;
import com.se1.tut07.repository.CompanyRepository;
import com.se1.tut07.repository.EmployeeRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private CompanyRepository companyRepository;

    // EmployeeController.java
    @GetMapping("/")
    public String listEmployees(
            @RequestParam(name = "searchName", required = false) String searchName,
            @RequestParam(name = "sortField", required = false, defaultValue = "id") String sortField,
            @RequestParam(name = "sortDirection", required = false, defaultValue = "asc") String sortDirection,
            Model model) {

        List<Employee> employees;
        if (searchName != null) {
            employees = employeeRepository.findByNameContainingIgnoreCase(searchName);
        } else {
            Sort sort = sortDirection.equalsIgnoreCase("asc")
                    ? Sort.by(sortField).ascending()
                    : Sort.by(sortField).descending();
            employees = employeeRepository.findAll(sort);
        }

        model.addAttribute("employees", employees);
        model.addAttribute("searchName", searchName);
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDirection", sortDirection);
        return "employeeList";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("employee", new Employee());
        List<Company> companies = companyRepository.findAll();
        model.addAttribute("companies", companies);
        return "employee/add";
    }

    @PostMapping("/save")
    public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<Company> companies = companyRepository.findAll();
            model.addAttribute("companies", companies);
            return "employee/add";
        }
        employeeRepository.save(employee);
        return "redirect:/employees/";
    }

    @GetMapping("/{id}")
    public String showEmployeeDetails(@PathVariable("id") Long id, Model model) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            model.addAttribute("employee", optionalEmployee.get());
            return "employee/detail";
        } else {
            return "redirect:/employees/";
        }
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            model.addAttribute("employee", optionalEmployee.get());
            List<Company> companies = companyRepository.findAll();
            model.addAttribute("companies", companies);
            return "employee/edit";
        } else {
            return "redirect:/employees/";
        }
    }

    @PostMapping("/{id}/update")
    public String updateEmployee(@PathVariable("id") Long id, @Valid @ModelAttribute("employee") Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<Company> companies = companyRepository.findAll();
            model.addAttribute("companies", companies);
            return "employee/edit";
        }
        employee.setId(id);
        employeeRepository.save(employee);
        return "redirect:/employees/";
    }

    @GetMapping("/{id}/delete")
    public String deleteEmployee(@PathVariable("id") Long id) {
        employeeRepository.deleteById(id);
        return "redirect:/employees/";
    }
}