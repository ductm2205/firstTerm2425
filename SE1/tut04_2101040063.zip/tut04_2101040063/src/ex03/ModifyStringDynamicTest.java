package ex03;

import ex01.ModifyString;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ModifyStringDynamicTest {
    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                DynamicTest.dynamicTest("Test 1", () -> assertEquals("Hello", ModifyString.modifyString(" hello "))),
                DynamicTest.dynamicTest("Test 2", () -> assertEquals("JavaIsCool", ModifyString.modifyString(" java is cool ")))
        );
    }
}
