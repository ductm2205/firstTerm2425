package se1.tut08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut08Application {

	public static void main(String[] args) {
		SpringApplication.run(Tut08Application.class, args);
	}

}
