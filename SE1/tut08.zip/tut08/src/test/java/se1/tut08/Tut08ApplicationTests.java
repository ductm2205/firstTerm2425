package se1.tut08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
