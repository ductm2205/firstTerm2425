const express = require('express');
const app = express();
const mysql = require('mysql2');

app.use(express.static('public'))

const connect = mysql.createConnection({
    user: 'root',
    password: '123456',
    database: 'wprtut09act2'
}).promise()

app.get('/games/genres', async (req, res) => {
    let [rows] = await connect.query(`SELECT * FROM genres order by genre_name asc;`)
    res.json(rows);
})

app.get('/games/list/:genreid/:year', async (req, res) => {
    let genreid = req.params.genreid;
    let year = req.params.year;
    let [rows] = await connect.query(`SELECT id, name, platform, publisher from  games where genre = ${genreid} and release_year = ${year} limit 3;`)
    res.json(rows);
})


app.listen(8000);