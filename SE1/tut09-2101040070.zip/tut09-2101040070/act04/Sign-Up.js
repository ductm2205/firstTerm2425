const express = require('express');
const app = express();
const path = require('path');
const mysql = require('mysql2');
const multer = require('multer');
const { engine } = require('express-handlebars');
app.use(multer().none());



app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'))


const connect = mysql.createConnection({
    user: 'root',
    password: '123456',
    database: 'wprtut09act4'
}).promise();

app.get('/register', (req, res) => {
    res.render('register');
})

app.post('/register', async (req, res) => {
    let usn = req.body.usn;
    let pass = req.body.pass;
    let rePass = req.body.rePass;

    console.log(req.body);


    if (!usn) {
        return res.send('Username is required.');
    } else if (!pass) {
        return res.send('Password is required.');
    } else if (pass !== rePass) {
        return res.send('Passwords do not match.');
    }

    try {
        const [result] = await connect.query(
            'INSERT INTO users (usn, pass) VALUES (?, ?)',
            [usn, pass]
        );
        res.send('User added successfully.');

    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.send('Username already exists.');
        }
        return res.send('Database error.');
    }


})
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});