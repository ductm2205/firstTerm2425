document.addEventListener('click', function () {
    const genreSelect = document.getElementById('genres');
    const yearInput = document.getElementById('year');
    const resultDiv = document.getElementById('result');
    const button = document.getElementById('myBtn');

    fetch('/games/genres')
        .then(response => response.json())
        .then(genres => {
            genres.forEach(genre => {
                const option = document.createElement('option');
                option.value = genre.id;
                option.text = genre.genre_name;
                genreSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching genres:', error));

    button.addEventListener('click', function () {
        const selectedGenreId = genreSelect.value;
        const year = yearInput.value;

        if (!selectedGenreId || !year || isNaN(year)) {
            alert('Please select a valid genre and enter a valid year.');
            return;
        }

        fetch(`/games/list/${selectedGenreId}/${year}`)
            .then(response => response.json())
            .then(data => {
                resultDiv.innerHTML = '';

                const table = document.createElement('table');
                table.setAttribute('border', '1');

                const headerRow = table.insertRow();
                headerRow.insertCell().innerText = 'ID';
                headerRow.insertCell().innerText = 'Game Title';
                headerRow.insertCell().innerText = 'Publisher';
                headerRow.insertCell().innerText = 'Platform';

                if (data.length === 0) {
                    const noDataRow = table.insertRow();
                    const noDataCell = noDataRow.insertCell();
                    noDataCell.colSpan = 4;
                    noDataCell.innerText = 'No games found for the selected genre and year.';
                } else {
                    data.forEach(game => {
                        const row = table.insertRow();
                        row.insertCell().innerText = game.id;
                        row.insertCell().innerText = game.name;
                        row.insertCell().innerText = game.publisher;
                        row.insertCell().innerText = game.platform;
                    });
                }

                resultDiv.appendChild(table);
            })
            .catch(error => console.error('Error fetching games:', error));
    });
});
