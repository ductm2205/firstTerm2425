"use strict";
(function () {
  window.addEventListener("load", init);

  /**
   * init - sets up the event listener for the Solve button
   */
  function init() {
    const solveButton = document.querySelector("button");
    solveButton.addEventListener("click", solveEquation);
  }

  /**
   * solveEquation - handles the solving of the quadratic equation
   */
  function solveEquation() {
    const a = parseFloat(document.getElementById("a").value);
    const b = parseFloat(document.getElementById("b").value);
    const c = parseFloat(document.getElementById("c").value);

    const resultDiv = document.getElementById("result");

    // Check if inputs are valid numbers
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      resultDiv.textContent = "Please enter valid numbers for a, b, and c.";
      return;
    }

    // Check if a is zero (not a quadratic equation)
    if (a === 0) {
      resultDiv.textContent =
        "The value of 'a' cannot be zero for a quadratic equation.";
      return;
    }

    // Calculate the discriminant
    const discriminant = b * b - 4 * a * c;

    let result;
    if (discriminant > 0) {
      // Two real roots
      const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
      const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
      result = `The roots are x₁ = ${x1.toFixed(2)} and x₂ = ${x2.toFixed(2)}`;
    } else if (discriminant === 0) {
      // One real root
      const x = -b / (2 * a);
      result = `The equation has one root: x = ${x.toFixed(2)}`;
    } else {
      // Complex roots
      const realPart = -b / (2 * a);
      const imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
      result = `The roots are complex: x₁ = ${realPart.toFixed(
        2
      )} + ${imaginaryPart.toFixed(2)}i and x₂ = ${realPart.toFixed(
        2
      )} - ${imaginaryPart.toFixed(2)}i`;
    }

    resultDiv.textContent = result;
  }
})();
